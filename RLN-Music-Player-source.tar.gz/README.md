# RLN Music Player

Lettore musicale Android per smartphone e tablet, sviluppato a partire da OpenTune.

Il progetto mantiene le funzioni Android della base originale: riproduzione locale e online, radio Internet, playlist, testi, Cast, DLNA, Android Auto, equalizzatore e aggiornamenti in-app. La presenza nel codice non equivale a una verifica su ogni dispositivo o fonte: Cast, DLNA e gli aggiornamenti RLN richiedono ancora prove dedicate.

## Sviluppo

Il progetto Gradle include soltanto `:app` e `:core`. Le build desktop, web, Wear OS e Android TV non fanno parte di questo prodotto.

Aprire il progetto in Android Studio oppure usare `./gradlew :app:assembleDebug`.

## Licenza e attribuzione

RLN Music Player deriva da OpenTune, distribuito con licenza GNU GPL v3. Il file `LICENSE` e gli avvisi in `THIRD_PARTY_NOTICES.md` restano inclusi. Le modifiche al codice devono essere rese disponibili secondo gli obblighi della GPL-3.0.
