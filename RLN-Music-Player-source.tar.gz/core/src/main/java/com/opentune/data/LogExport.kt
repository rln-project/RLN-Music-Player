package com.opentune.data

import android.os.Build
import android.os.Process
import com.opentune.core.BuildConfig
import com.opentune.data.account.AccountStore
import com.opentune.playback.playbackDiagnostics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Builds the user-initiated, redacted playback diagnostic report. */
object LogExport {
    suspend fun recent(): String = withContext(Dispatchers.IO) {
        val header = buildString {
            appendLine("RLN Music Player ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})${if (BuildConfig.DEBUG) " debug" else ""}")
            appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Signed in: ${AccountStore.signedIn.value}")
        }
        val own = AppLog.snapshot().joinToString("\n").let(DiagnosticRedactor::redact).takeLast(OWN_CHARS)
        val system = runCatching {
            val process = ProcessBuilder(
                "logcat", "-d", "-t", "400", "--pid", Process.myPid().toString(), "*:W",
            ).redirectErrorStream(true).start()
            process.inputStream.bufferedReader().use { it.readText() }.let(DiagnosticRedactor::redact).takeLast(SYSTEM_CHARS)
        }.getOrElse { "Couldn't read logcat: ${it.message}" }
        val crash = CrashLog.last()?.let { "\n\n== Last crash ==\n$it" }.orEmpty()
        val timeline = playbackDiagnostics.snapshot()
        DiagnosticRedactor.redact(
            "$header\n== Playback timeline ==\n$timeline\n\n== App log ==\n$own" +
                "\n\n== System warnings and errors ==\n$system$crash",
        )
    }

    // Clipboard and share intents travel through a 1 MB binder buffer.
    private const val OWN_CHARS = 80_000
    private const val SYSTEM_CHARS = 20_000
}
