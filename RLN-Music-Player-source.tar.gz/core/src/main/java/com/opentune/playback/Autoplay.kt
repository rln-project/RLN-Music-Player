package com.opentune.playback

import com.opentune.data.library.HiddenList
import com.opentune.data.model.Song

/**
 * When to extend the queue with radio, and with what. Kept free of Android
 * types so the rules can be tested without a device.
 */
object Autoplay {

    /**
     * How close to the end of the queue playback gets before more radio is
     * fetched. Three tracks of slack give slow catalogues time to answer
     * before the queue runs dry, including when the listener skips a song.
     */
    const val TRACKS_BEFORE_END = 3

    /** Rounds of asking for radio at their quick pace, before it slows to once a minute. */
    const val EAGER_ROUNDS = 4

    /**
     * How long to wait before round [round] of asking for radio: none for the first, then 10,
     * 20 and 30 seconds, then a minute each time, for as long as the queue still needs it.
     */
    fun radioPause(round: Int): Long = when (round) {
        0 -> 0L
        1 -> 10_000L
        2 -> 20_000L
        3 -> 30_000L
        else -> 60_000L
    }

    /**
     * When every song the radios have is in the queue already: your own most played songs that
     * aren't ([excluded] says which can't go), those by the queue's own artists first, so the
     * music carries on in the same vein instead of stopping.
     */
    fun fromHistory(
        records: List<com.opentune.data.history.PlayRecord>,
        queue: List<Song>,
        limit: Int = 20,
        excluded: (Song) -> Boolean,
    ): List<Song> {
        val queueArtists = queue.mapTo(HashSet()) { artistKey(it) }
        val songs = records.groupBy { it.videoId }.values
            .sortedByDescending { it.size }
            .map { it.first().toSong() }
            .filterNot(excluded)
        val (near, rest) = songs.partition { artistKey(it) in queueArtists }
        return spreadArtists((near + rest).take(limit))
    }

    /** Use ready, playable recommendations without waiting for every secondary seed. */
    internal suspend fun readyRadios(
        requests: List<kotlinx.coroutines.Deferred<List<Song>>>,
        usable: (Song) -> Boolean,
        graceMs: Long = 250,
    ): List<List<Song>> {
        val pending = requests.indices.toMutableSet()
        val answers = MutableList(requests.size) { emptyList<Song>() }
        var deadline: Long? = null
        suspend fun next(): Pair<Int, List<Song>> = kotlinx.coroutines.selects.select {
            pending.forEach { i -> requests[i].onAwait { i to it } }
        }
        try {
            while (pending.isNotEmpty()) {
                val left = deadline?.let { (it - System.nanoTime()) / 1_000_000 }
                if (left != null && left <= 0) break
                val answer = if (left == null) next() else kotlinx.coroutines.withTimeoutOrNull(left) { next() } ?: break
                val (index, songs) = answer
                pending.remove(index)
                answers[index] = songs
                if (deadline == null && songs.any(usable)) deadline = System.nanoTime() + graceMs * 1_000_000
            }
            return answers
        } finally {
            requests.forEach { if (!it.isCompleted) it.cancel() }
        }
    }

    /**
     * @param remaining tracks still to play after the current one, in play
     *   order (which differs from queue order while shuffle is on).
     */
    fun shouldExtend(remaining: Int, queueSize: Int): Boolean =
        queueSize > 0 && remaining <= TRACKS_BEFORE_END

    /**
     * The radio tracks worth appending: anything not already queued, once
     * each. The radio for a track always lists that track first, and
     * neighbouring seeds overlap heavily, so most of a second fetch is
     * already in the queue.
     */
    fun newTracks(queuedIds: Set<String>, radio: List<Song>): List<Song> =
        radio.filter { it.videoId !in queuedIds }.distinctBy { it.videoId }

    /** How many songs the next radio is based on, the last queued one included. */
    const val MAX_SEEDS = 3

    /** How far back through the queue the other seeds can come from. */
    const val SEED_WINDOW = 12

    /**
     * The songs to base more radio on: the last one queued, then earlier ones
     * walking back through the end of the queue, one per artist, so a queue
     * that moved between artists carries on from all of them, not only the
     * last. [usable] says which songs have radio at all.
     */
    fun seeds(queue: List<Song>, usable: (Song) -> Boolean): List<Song> {
        val last = queue.lastOrNull()?.takeIf(usable) ?: return emptyList()
        val picked = mutableListOf(last)
        val artists = mutableSetOf(artistKey(last))
        for (song in queue.dropLast(1).takeLast(SEED_WINDOW).asReversed()) {
            if (picked.size >= MAX_SEEDS) break
            if (!usable(song) || picked.any { it.videoId == song.videoId }) continue
            if (artists.add(artistKey(song))) picked += song
        }
        return picked
    }

    /**
     * One list from the radios of [seeds]' songs, [radios] in the same order,
     * the last song's first. A song scores for how high it sits in each radio
     * (the last song's radio counts most), more when several radios agree on
     * it, and a little more when its artist is already in [queue]. Then no
     * artist plays twice in a row where another can go between.
     */
    fun blend(radios: List<List<Song>>, queue: List<Song>): List<Song> {
        if (radios.size <= 1) return radios.firstOrNull().orEmpty()
        val known = queue.mapTo(HashSet()) { artistKey(it) }
        val scores = LinkedHashMap<String, Double>()
        val seen = HashMap<String, Int>()
        val songs = HashMap<String, Song>()
        radios.forEachIndexed { r, radio ->
            val weight = if (r == 0) 1.0 else OTHER_SEED_WEIGHT
            val list = radio.distinctBy { it.videoId }
            list.forEachIndexed { i, song ->
                songs.putIfAbsent(song.videoId, song)
                val agreeing = seen.merge(song.videoId, 1, Int::plus)!! - 1
                scores[song.videoId] = (scores[song.videoId] ?: 0.0) + weight * (1.0 - i.toDouble() / list.size) + agreeing * AGREE_BONUS
            }
        }
        val ranked = scores.entries
            .sortedByDescending { (id, score) -> score + if (artistKey(songs.getValue(id)) in known) FAMILIAR_BONUS else 0.0 }
            .map { songs.getValue(it.key) }
        return spreadArtists(ranked)
    }

    /** [ranked] in order, except a song by the artist just placed waits for the next song by someone else. */
    internal fun spreadArtists(ranked: List<Song>): List<Song> {
        val out = ArrayList<Song>(ranked.size)
        val waiting = ArrayDeque<Song>()
        for (song in ranked) {
            if (out.isNotEmpty() && artistKey(out.last()) == artistKey(song)) {
                waiting += song
                continue
            }
            out += song
            val next = waiting.firstOrNull { artistKey(it) != artistKey(song) }
            if (next != null) {
                waiting.remove(next)
                out += next
            }
        }
        out += waiting
        return out
    }

    // A song with no artist named is nobody else's.
    private fun artistKey(song: Song) = HiddenList.normalize(HiddenList.mainArtist(song.artist)).ifEmpty { "#" + song.videoId }

    private const val OTHER_SEED_WEIGHT = 0.6
    private const val AGREE_BONUS = 0.25
    private const val FAMILIAR_BONUS = 0.15
}
