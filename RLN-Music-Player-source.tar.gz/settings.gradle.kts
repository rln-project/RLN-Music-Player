pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // NewPipeExtractor (YouTube stream resolution) is published via JitPack.
        maven("https://jitpack.io")
    }
}

rootProject.name = "RLN Music Player"
include(":app")
include(":core")
