package com.opentune.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.opentune.R
import kotlinx.coroutines.delay
import kotlin.math.exp

/** Plays once per launch of the app, not each time the screen is rebuilt. */
object Opening {
    var played = false
}

/** The splash field matches the launcher background. */
val OPENING_FIELD = Color(0xFF17051E)

/** Displays the RLN headphones and record, then scales them away to reveal the app. */
@Composable
fun OpeningReveal(onDive: (Float) -> Unit, onDone: () -> Unit) {
    val settle = remember { Animatable(0f) }
    val dive = remember { Animatable(0f) }
    val done by rememberUpdatedState(onDone)
    val report by rememberUpdatedState(onDive)

    LaunchedEffect(Unit) {
        settle.animateTo(1f, tween(620, easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)))
        delay(120L)
        dive.animateTo(1f, tween(900, easing = CubicBezierEasing(0.6f, 0f, 0.85f, 0.35f))) {
            report(value)
        }
        report(1f)
        done()
    }

    val progress = dive.value
    val fade = 1f - smooth(0.78f, 1f, progress)
    val breathe = 1f + 0.035f * kotlin.math.sin(Math.PI.toFloat() * settle.value)
    val scale = breathe * exp(kotlin.math.ln(86f) * progress * progress)

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(OPENING_FIELD.copy(alpha = fade)))
        Image(
            painter = painterResource(R.drawable.rln_music_player_icon),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.Center)
                .size(232.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .alpha(fade),
        )
    }
}

private fun smooth(from: Float, to: Float, x: Float): Float {
    val t = ((x - from) / (to - from)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}
