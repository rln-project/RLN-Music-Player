package com.opentune.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.opentune.ui.theme.Icon
import com.opentune.ui.theme.Text
import com.opentune.R

/** Clickable RLN Radio Telegram bot banner. */
@Composable
internal fun CommunityBanner(modifier: Modifier = Modifier, onOpenBot: () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(3f)
            .clip(RoundedCornerShape(28.dp))
            .clickable(onClick = onOpenBot),
    ) {
        Image(
            painter = painterResource(R.drawable.rln_radio_bot_banner),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            modifier = Modifier
                .align(androidx.compose.ui.Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE600101A))))
                .padding(horizontal = 18.dp, vertical = 14.dp),
        ) {
            Box(
                contentAlignment = androidx.compose.ui.Alignment.Center,
                modifier = Modifier
                    .size(42.dp)
                    .background(Color(0xFF229ED9), CircleShape),
            ) {
                Icon(Icons.AutoMirrored.Rounded.Send, null, Modifier.size(22.dp), tint = Color.White)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("BOT TELEGRAM · RADIO RLN", style = MaterialTheme.typography.labelMedium, color = Color(0xFF8DDBFF))
                Text("Apri @RadioMessenger_bot", style = MaterialTheme.typography.titleSmall, color = Color.White)
            }
            Icon(Icons.Rounded.ChevronRight, "Apri il bot Telegram", tint = Color.White)
        }
    }
}
