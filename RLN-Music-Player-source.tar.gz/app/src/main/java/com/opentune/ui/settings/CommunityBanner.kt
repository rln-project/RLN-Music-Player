package com.opentune.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.opentune.R

/** Clickable RLN Radio Telegram bot banner. */
@Composable
internal fun CommunityBanner(modifier: Modifier = Modifier, onOpenBot: () -> Unit) {
    Image(
        painter = painterResource(R.drawable.rln_radio_bot_banner),
        contentDescription = "Apri il bot Telegram della radio RLN",
        contentScale = ContentScale.Crop,
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(3f)
            .clip(RoundedCornerShape(28.dp))
            .clickable(onClick = onOpenBot),
    )
}
