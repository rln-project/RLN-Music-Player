package com.opentune.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.opentune.R
import com.opentune.ui.theme.Icon
import com.opentune.ui.theme.Text

@Composable
internal fun CommunityBanner(modifier: Modifier = Modifier, onOpenBot: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            painter = painterResource(R.drawable.rln_home_wordmark),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth().aspectRatio(3f),
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
                .padding(top = 8.dp)
                .clip(RoundedCornerShape(20.dp))
                .clickable(onClick = onOpenBot)
                .padding(horizontal = 18.dp, vertical = 12.dp),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(42.dp).background(Color(0xFF229ED9), CircleShape),
            ) {
                Icon(Icons.AutoMirrored.Rounded.Send, null, Modifier.size(22.dp), tint = Color.White)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp, end = 8.dp)) {
                Text("BOT TELEGRAM · RADIO RLN", style = MaterialTheme.typography.labelMedium, color = colors.primary)
                Text("Apri @RadioMessenger_bot", style = MaterialTheme.typography.titleSmall, color = colors.onSurface)
            }
            Icon(Icons.Rounded.ChevronRight, null, tint = colors.onSurfaceVariant)
        }
    }
}
