package com.opentune.ui.player

import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import com.opentune.data.settings.AppSettings
import com.opentune.ui.components.livingArt

import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.media.AudioManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeDown
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.CircularProgressIndicator
import com.opentune.ui.theme.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.opentune.ui.theme.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.unit.Dp
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import androidx.compose.animation.animateColorAsState
import com.opentune.ui.theme.rememberArtworkSeed
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.shape.RoundedCornerShape
import com.opentune.ui.components.glass
import androidx.compose.runtime.snapshotFlow
import com.opentune.ui.components.pressable
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.toArgb
import com.materialkolor.hct.Hct
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.opentune.data.NerdStats
import com.opentune.data.model.ROW_ART_PX
import com.opentune.playback.AudioFormatInfo
import com.opentune.data.model.Song
import com.opentune.data.model.artworkAt
import com.opentune.data.settings.PlayerBackground
import com.opentune.ui.components.Artwork
import com.opentune.ui.formatTime
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import coil3.request.allowHardware

/**
 * The full player's backdrop, in the style chosen in settings. With
 * [fullCover] the artwork itself runs edge to edge across the top and fades
 * into the background below it.
 */
@Composable
fun PlayerBackdrop(
    style: PlayerBackground,
    artworkUrl: String?,
    modifier: Modifier = Modifier,
    animate: Boolean = true,
    fullCover: Boolean = false,
    /** Where the player's cover area ends, from the top; the full cover runs a little past it. */
    fullCoverBottom: Dp? = null,
    /** Let the full cover drift and zoom while playing (see livingArt). */
    movingCover: Boolean = false,
    playing: Boolean = false,
    /** The Canvas runs only on this stricter signal: really sounding, not just meant to play. */
    canvasPlaying: Boolean = playing,
    /** How the full-screen cover changes to the next song's, and where that song is in the queue. */
    change: com.opentune.data.settings.CoverChange = com.opentune.data.settings.CoverChange.FADE,
    index: Int = 0,
    /** The playing song, so a sharper copy of its cover swaps in place rather than as a song change. */
    songId: String? = null,
    /** Spotify's Canvas for the playing song, looped over the whole backdrop. */
    canvas: String? = null,
    /** Where the title starts, from the top: over a Canvas, the frost begins a little above it. */
    titleTop: Dp? = null,
    /** Lyrics or the queue are open over the Canvas: it's frosted and darkened all the way up. */
    canvasBehindText: Boolean = false,
    fullCoverVisible: Boolean = true,
    artworkMotion: com.opentune.ui.components.ArtworkMotion? = null,
    /** Apple's animated cover for the playing song, looped over the full-screen still. */
    video: com.opentune.data.covers.AppleMotionArt.Motion? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val ui by com.opentune.data.settings.AppSettings.ui.collectAsState()
    val seed = rememberArtworkSeed(artworkUrl)
    // With the setting on, the full-screen cover's own colour is the backdrop:
    // the cover fades into itself and the player reads as one surface.
    val matched = if (ui.coverColorBackground && fullCover) seed else null
    if (style == PlayerBackground.AMOLED) {
        Box(modifier.background(Color.Black))
        return
    }
    // The cover's own colours, not the scheme's turned ones, so each background looks like the cover.
    val tones = rememberCoverTones(artworkUrl)
    Box(modifier.background(matched ?: tones.base)) {
        if (matched == null) {
            when (style) {
                PlayerBackground.AMOLED -> Unit
                PlayerBackground.ECHO_GLOW -> EchoGlowBackground(animate && playing, Modifier.matchParentSize(), tones.lights, tones.base)
                PlayerBackground.BLUR -> CoverBlur(artworkUrl, animate && playing, Modifier.matchParentSize(), tones)
                PlayerBackground.MESH -> MeshGradient(artworkUrl, animate, Modifier.matchParentSize())
                PlayerBackground.GRADIENT -> {
                    // The cover's main colour at the top, its second colour coming in from a corner,
                    // both deepening to the cover's near-black by the controls.
                    val top = tones.deep
                    Box(
                        Modifier.matchParentSize()
                            .background(
                                Brush.verticalGradient(
                                    0f to top,
                                    0.32f to lerp(top, tones.base, 0.3f),
                                    0.66f to lerp(top, tones.base, 0.82f),
                                    1f to tones.base,
                                ),
                            )
                            .drawBehind {
                                drawRect(Brush.radialGradient(
                                    *com.opentune.ui.components.glowStops(tones.second, 0.75f, shape = 1.5f),
                                    center = androidx.compose.ui.geometry.Offset(size.width * 0.95f, size.height * 0.08f),
                                    radius = size.width.coerceAtLeast(1f) * 1.1f,
                                ))
                                with(com.opentune.ui.components.Dither) { drawDither(0.05f) }
                            },
                    )
                    // Under the controls, a faint glow in the cover's colours.
                    androidx.compose.foundation.layout.BoxWithConstraints(Modifier.matchParentSize()) {
                        AmbientLights(
                            tones.lights.take(3),
                            playing = playing,
                            animate = animate,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(maxHeight * 0.5f)
                                .align(Alignment.BottomCenter)
                                .graphicsLayer { alpha = 0.35f },
                        )
                    }
                }
            }
        }
        if (canvas != null) {
            CanvasBackdrop(canvas, canvasPlaying, titleTop, canvasBehindText, Modifier.matchParentSize())
        } else if (fullCover) {
            CoverSwap(CoverShown(artworkUrl, index, songId), change) { url, motion ->
                // The cover runs from the top down to just behind the title and
                // fades out there into whatever backdrop is below it, with a light
                // scrim at the top so the status line stays readable. It's never
                // shorter than it is wide; taller, it's cropped at the sides.
                androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().graphicsLayer { alpha = if (fullCoverVisible) 1f else 0f }) {
                    val height = maxOf(maxWidth / 0.9f, (fullCoverBottom ?: 0.dp) + FULL_COVER_OVERLAP)
                    val solid = (1f - FULL_COVER_FADE / height).coerceIn(0.4f, 0.8f)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(height)
                            .then(motion)
                            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                            .drawWithContent {
                                drawContent()
                                drawRect(
                                    Brush.verticalGradient(solid to Color.Black, 1f to Color.Transparent),
                                    blendMode = BlendMode.DstIn,
                                )
                            },
                    ) {
                        UpgradingArtwork(
                            url.artworkAt(com.opentune.data.model.PLAYER_ART_PX),
                            Modifier.matchParentSize(),
                            shape = RectangleShape,
                            imageModifier = Modifier.livingArt(playing, movingCover, artworkMotion),
                        ) {
                            // The animated cover loops over the still one, as on the plain cover;
                            // a Canvas takes the backdrop over instead, so not under one.
                            if (video != null && canvas == null && url == artworkUrl) {
                                val quality = com.opentune.data.settings.AppSettings.ui.collectAsState().value.motionQuality
                                // Keyed on the quality, so a new choice in Settings takes effect at once.
                                androidx.compose.runtime.key(quality) {
                                    LoopingVideo(video.url, playing, Modifier.matchParentSize(), fallbackUrl = video.fallbackUrl, maxPx = quality.maxPx, maxBitrate = quality.maxBitrate)
                                }
                            }
                        }
                        Box(Modifier.matchParentSize().background(Brush.verticalGradient(0f to Color.Black.copy(alpha = com.opentune.ui.components.FULL_COVER_TOP_SHADE), 0.2f to Color.Transparent)))
                    }
                }
            }
        }
    }
}

/**
 * Spotify's Canvas filling the player, sharp at the top, with the chosen look
 * from just above the title down to the bottom, where the title, seek bar and
 * buttons sit, so they read over any clip. Each look comes in gradually over
 * the first stretch rather than starting at a line:
 *
 * - Tint: the clip fades into the song's own colour.
 * - Dark: it fades to near black.
 * - Frosted: frosted glass, the clip blurred behind it with a lit rim along the
 *   top. The clip is drawn by a TextureView, which a Compose blur can't see, so
 *   the frost is made from small frames taken from it and drawn soft; it works
 *   on every phone, blurred further where Android can blur (12 and up).
 * - Plain: only a light darkening behind the controls.
 */
@Composable
private fun CanvasBackdrop(canvas: String, playing: Boolean, titleTop: Dp?, behindText: Boolean, modifier: Modifier) {
    val ui by com.opentune.data.settings.AppSettings.ui.collectAsState()
    val look = ui.canvasLook
    val frost = look == com.opentune.data.settings.CanvasLook.FROST && !ui.reduceBlur && !ui.liteMode
    var video by remember { mutableStateOf<android.view.TextureView?>(null) }
    androidx.compose.foundation.layout.BoxWithConstraints(modifier) {
        // Keyed on the clip, so the next song's starts fresh and fades in over this one's backdrop.
        androidx.compose.runtime.key(canvas) {
            LoopingVideo(canvas, playing, Modifier.matchParentSize(), maxPx = 1920, maxBitrate = 8_000_000,
                onView = if (frost) ({ v -> video = v }) else null)
        }
        // A light scrim at the top so the status bar and "Playing from" stay readable.
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(0f to Color.Black.copy(alpha = 0.35f), 0.18f to Color.Transparent)))
        // Over lyrics and the queue the look starts at the very top, moving up there as they open.
        // The box keeps its full size throughout and only where the look begins moves, read while
        // drawing, so nothing is laid out again on each frame.
        val density = androidx.compose.ui.platform.LocalDensity.current
        val toPx = with(density) { ((titleTop ?: (maxHeight * 0.55f)) - CANVAS_FROST_LEAD).coerceIn(0.dp, maxHeight).toPx() }
        val from = androidx.compose.animation.core.animateFloatAsState(toPx, androidx.compose.animation.core.tween(450), label = "canvasFrost")
        val shade = androidx.compose.animation.core.animateFloatAsState(if (behindText) 1f else 0f, androidx.compose.animation.core.tween(450), label = "canvasShade")
        val ramp = with(density) { (CANVAS_FROST_LEAD * 2).toPx() }
        val scheme = MaterialTheme.colorScheme
        // Behind lyrics and the queue: a wash of the song's colour, deep enough for text over any frame.
        val wash = lerp(scheme.surface, Color.Black, 0.35f)
        // The song's own colour, deep but still clearly a colour (the surface is all but black in a dark theme).
        val songTone = lerp(lerp(scheme.primaryContainer, scheme.primary, 0.35f), Color.Black, 0.5f)
        if (frost) {
            VideoFrost(remember { TextureFrames { video } }, playing, Modifier.matchParentSize(), from, ramp)
        }
        Box(
            Modifier
                .matchParentSize()
                .drawBehind {
                    val start = from.value
                    val span = (size.height - start).coerceAtLeast(1f)
                    val inAt = (ramp / span).coerceIn(0.05f, 0.9f)
                    val (tone, mid, foot) = when (look) {
                        com.opentune.data.settings.CanvasLook.TINT -> Triple(songTone, 0.78f, 0.94f)
                        com.opentune.data.settings.CanvasLook.SHADE -> Triple(Color.Black, 0.66f, 0.9f)
                        // Over the frost, only enough shade for white text on a bright clip.
                        com.opentune.data.settings.CanvasLook.FROST -> Triple(Color.Black, if (frost) 0.14f else 0.45f, if (frost) 0.4f else 0.8f)
                        com.opentune.data.settings.CanvasLook.NONE -> Triple(Color.Black, 0.22f, 0.62f)
                    }
                    drawRect(
                        Brush.verticalGradient(
                            0f to tone.copy(alpha = 0f),
                            inAt to tone.copy(alpha = mid),
                            1f to tone.copy(alpha = foot),
                            startY = start,
                            endY = size.height,
                        ),
                        topLeft = androidx.compose.ui.geometry.Offset(0f, start),
                    )
                    val k = shade.value
                    if (k > 0f) drawRect(
                        Brush.verticalGradient(
                            0f to wash.copy(alpha = 0.74f * k),
                            0.5f to wash.copy(alpha = 0.82f * k),
                            1f to wash.copy(alpha = 0.9f * k),
                        ),
                    )
                },
        )
    }
}

/**
 * Frosted glass over the Canvas from [from] down: small frames of the clip from [frames],
 * taken about 15 times a second (twice a second while paused), drawn scaled up and
 * blurred, faded in over [ramp], with a soft white sheen and a lit rim along its top
 * edge, as liquid glass. A frame 1/16 the size is little work, so this
 * costs far less than blurring the clip at full size.
 * The frames are blurred as they're taken ([softenFrame]), so the glass is frosted
 * on every phone.
 */
/** Where the frost's frames come from: how big the picture is now, and a copy of it scaled into a bitmap. */
internal interface FrostFrames {
    fun size(): androidx.compose.ui.unit.IntSize?
    fun copyInto(bitmap: android.graphics.Bitmap): Boolean
}

/** A TextureView's picture, as [FrostFrames]. */
private class TextureFrames(private val view: () -> android.view.TextureView?) : FrostFrames {
    override fun size() = view()?.takeIf { it.isAvailable && it.width > 0 && it.height > 0 }?.let { androidx.compose.ui.unit.IntSize(it.width, it.height) }
    override fun copyInto(bitmap: android.graphics.Bitmap) = runCatching { view()!!.getBitmap(bitmap) }.isSuccess
}

@Composable
internal fun VideoFrost(
    frames: FrostFrames,
    playing: Boolean,
    modifier: Modifier,
    from: androidx.compose.runtime.State<Float>,
    ramp: Float,
) {
    val frame = remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    val tick = remember { androidx.compose.runtime.mutableIntStateOf(0) }
    LaunchedEffect(playing) {
        // Two bitmaps in turn, so the one drawn is never the one being filled.
        val spare = arrayOfNulls<android.graphics.Bitmap>(2)
        val pixels = FrostPixels()
        var turn = 0
        while (true) {
            val at = frames.size()
            if (at != null) {
                val w = (at.width / FROST_SCALE).coerceAtLeast(8)
                val h = (at.height / FROST_SCALE).coerceAtLeast(8)
                val target = spare[turn]?.takeIf { it.width == w && it.height == h }
                    ?: android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888).also { spare[turn] = it }
                if (frames.copyInto(target)) {
                    softenFrame(target, pixels)
                    frame.value = target
                    tick.intValue++
                    turn = 1 - turn
                }
            }
            kotlinx.coroutines.delay(if (playing) FROST_FRAME_MS else 500L)
        }
    }
    val paint = remember { android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG) }
    Box(
        modifier
            // The frost fades in from where it starts, drawn into its own layer to be masked.
            .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                val start = from.value
                drawRect(
                    Brush.verticalGradient(0f to Color.Transparent, 1f to Color.Black, startY = start, endY = start + ramp),
                    blendMode = androidx.compose.ui.graphics.BlendMode.DstIn,
                )
            },
    ) {
        androidx.compose.foundation.Canvas(
            Modifier.matchParentSize().blur(FROST_BLUR, androidx.compose.ui.draw.BlurredEdgeTreatment.Rectangle),
        ) {
            tick.intValue
            val b = frame.value ?: return@Canvas
            drawIntoCanvas { c ->
                c.nativeCanvas.drawBitmap(b, null, android.graphics.RectF(0f, 0f, size.width, size.height), paint)
            }
            // The glass: a faint white film, lighter towards the top.
            drawRect(Brush.verticalGradient(0f to Color.White.copy(alpha = 0.1f), 1f to Color.White.copy(alpha = 0.03f)))
        }
        // Its lit top edge, as light catches the rim of a pane.
        androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
            val start = from.value + ramp * 0.55f
            drawRect(
                Brush.verticalGradient(
                    0f to Color.White.copy(alpha = 0f),
                    0.5f to Color.White.copy(alpha = 0.16f),
                    1f to Color.White.copy(alpha = 0f),
                    startY = start - 6.dp.toPx(), endY = start + 6.dp.toPx(),
                ),
                topLeft = androidx.compose.ui.geometry.Offset(0f, start - 6.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(size.width, 12.dp.toPx()),
            )
            with(com.opentune.ui.components.Dither) { drawDither(0.05f) }
        }
    }
}

/** Working space for [softenFrame], kept between frames. */
private class FrostPixels {
    var a = IntArray(0)
    var b = IntArray(0)
}

/**
 * Blurs [bitmap] in place: three box blurs each way, which come out close to a
 * Gaussian. On a frame 1/16 the clip's size each way this is a few thousand
 * pixels, and the frost is soft on every phone, not only where Android blurs.
 */
private fun softenFrame(bitmap: android.graphics.Bitmap, work: FrostPixels) {
    val w = bitmap.width
    val h = bitmap.height
    val n = w * h
    if (work.a.size != n) { work.a = IntArray(n); work.b = IntArray(n) }
    bitmap.getPixels(work.a, 0, w, 0, 0, w, h)
    repeat(3) {
        boxPass(work.a, work.b, w, h, FROST_RADIUS, horizontal = true)
        boxPass(work.b, work.a, w, h, FROST_RADIUS, horizontal = false)
    }
    bitmap.setPixels(work.a, 0, w, 0, 0, w, h)
}

/** One box blur of radius [r] along rows ([horizontal]) or columns, edges held. */
private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
    val lines = if (horizontal) h else w
    val len = if (horizontal) w else h
    val step = if (horizontal) 1 else w
    val size = 2 * r + 1
    for (line in 0 until lines) {
        val base = if (horizontal) line * w else line
        var sr = 0; var sg = 0; var sb = 0
        for (k in -r..r) {
            val c = src[base + k.coerceIn(0, len - 1) * step]
            sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF
        }
        for (i in 0 until len) {
            dst[base + i * step] = (0xFF shl 24) or ((sr / size) shl 16) or ((sg / size) shl 8) or (sb / size)
            val out = src[base + (i - r).coerceIn(0, len - 1) * step]
            val inn = src[base + (i + r + 1).coerceIn(0, len - 1) * step]
            sr += ((inn shr 16) and 0xFF) - ((out shr 16) and 0xFF)
            sg += ((inn shr 8) and 0xFF) - ((out shr 8) and 0xFF)
            sb += (inn and 0xFF) - (out and 0xFF)
        }
    }
}

/** The frost's frames are this many times smaller than the clip each way. */
private const val FROST_SCALE = 16
/** The blur on those frames, in their pixels: about 3 × 2 × 16 px of the clip. */
private const val FROST_RADIUS = 2
private const val FROST_FRAME_MS = 66L
/** Over the frames' own blur, where Android can blur (12 and up), a little more to smooth the scaling. */
private val FROST_BLUR = 8.dp

/** How far above the title the Canvas frost starts, and half the stretch it takes to come in fully. */
private val CANVAS_FROST_LEAD = 56.dp

/**
 * A cover whose [url] may be swapped for a sharper copy while it's shown:
 * the first stays drawn underneath until the new one has loaded and covers
 * it, so there's no blank frame between them. [overlay] goes on top, inside
 * the same frame.
 */
@Composable
private fun UpgradingArtwork(
    url: String?,
    modifier: Modifier,
    shape: androidx.compose.ui.graphics.Shape,
    imageModifier: Modifier = Modifier,
    overlay: @Composable androidx.compose.foundation.layout.BoxScope.() -> Unit = {},
) {
    val first = remember { url }
    Box(modifier) {
        Artwork(first, Modifier.matchParentSize(), shape = shape, imageModifier = imageModifier)
        if (url != null && url != first) {
            coil3.compose.AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.matchParentSize().clip(shape).then(imageModifier),
            )
        }
        Box(Modifier.matchParentSize().clip(shape)) { overlay() }
    }
}

/** How far a full-screen cover runs past its area, under the title, and how long its fade is. */
private val FULL_COVER_OVERLAP = 44.dp
private val FULL_COVER_FADE = 210.dp

/**
 * Wide, soft patches of the cover's own colours, several of them, laid over
 * the whole player and drifting slowly into each other, like Apple Music's
 * animated backgrounds. Darker toward the bottom so the controls read.
 * Still when [animate] is false.
 */
@Composable
private fun MeshGradient(artworkUrl: String?, animate: Boolean, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val palette = com.opentune.ui.theme.rememberArtworkPalette(artworkUrl)
    // The cover's colours, or the song's scheme until they've been read. Each
    // is kept between dark and mid so none of them glares behind white text.
    val wanted = remember(palette, scheme.primary, scheme.tertiary) {
        val cover = palette.ifEmpty { listOf(scheme.primary, scheme.tertiary, scheme.secondary, scheme.primaryContainer) }
            .map { Hct.fromInt(it.toArgb()) }
        // A cover of one hue (or greys and one hue) gets the scheme's second
        // accent too, so the patches don't all melt into one colour.
        val hues = cover.filter { it.chroma >= 12 }.map { it.hue }
        val oneHue = hues.all { h -> hues.all { abs(h - it).let { d -> minOf(d, 360 - d) } < 40 } }
        val extra = listOfNotNull(scheme.tertiary.takeIf { oneHue }, scheme.primaryContainer.takeIf { cover.size < 3 })
        // Dark greys stay dark, as shadow between the colours rather than haze.
        val all = (cover + extra.map { Hct.fromInt(it.toArgb()) }).map {
            val grey = it.chroma < 12
            Color(Hct.from(it.hue, if (grey) it.chroma else it.chroma * 1.15, it.tone.coerceIn(if (grey) 14.0 else 30.0, if (grey) 50.0 else 60.0)).toInt())
        }
        // The patches, then the deepest shade of the cover's main colour to lay them on.
        List(MESH_BLOBS) { all[it % all.size] } + Color(cover.first().withTone(12.0).toInt())
    }
    // Each colour eases into the next song's rather than jumping.
    val colors = wanted.mapIndexed { i, c -> animateColorAsState(c, tween(1_200), label = "mesh$i").value }
    // Every frame, so the colours flow rather than step. On a phone that can't keep up
    // (Lite mode, or glass that has gone lighter), a dozen steps a second: the mesh is
    // what the player's Liquid Glass samples, and each step makes it blur and bend again.
    val smooth = smoothBackdrop()
    val t by produceState(0.15f, animate, smooth) {
        if (!animate) return@produceState
        val start = withFrameNanos { it } - (value * MESH_CYCLE_NS).toLong()
        while (true) {
            if (!smooth) delay(MESH_STEP_MS)
            value = ((withFrameNanos { it } - start) % MESH_CYCLE_NS).toFloat() / MESH_CYCLE_NS
        }
    }
    Canvas(modifier) {
        drawRect(colors[MESH_BLOBS])
        val w = size.width
        val h = size.height
        val phase = t * 2 * PI.toFloat()
        for (i in 0 until MESH_BLOBS) {
            val p = MESH_PATHS[i]
            // Whole turns per drift, so the loop closes without a jump.
            val cx = w * (p[0] + 0.22f * cos(phase * p[2] + p[4]))
            val cy = h * (p[1] + 0.12f * sin(phase * p[3] + p[4]))
            val radius = maxOf(w, h) * (0.36f + 0.04f * sin(phase + i))
            val c = colors[i]
            drawCircle(
                // Bright well out, then easing to nothing, so no patch shows a rim.
                Brush.radialGradient(
                    *com.opentune.ui.components.glowStops(c, 1f, shape = 2.5f),
                    center = Offset(cx, cy),
                    radius = radius,
                ),
                radius = radius,
                center = Offset(cx, cy),
            )
        }
        // Darker toward the bottom so the title and controls stay readable.
        drawRect(
            Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0.06f),
                0.5f to Color.Black.copy(alpha = 0.2f),
                1f to Color.Black.copy(alpha = 0.5f),
            ),
        )
        // Fine grain, so the wide soft fields don't show as bands.
        with(com.opentune.ui.components.Dither) { drawDither() }
    }
}

/** Whether animated backgrounds can move every frame on this phone. */
@Composable
internal fun smoothBackdrop(): Boolean {
    val ui by com.opentune.data.settings.AppSettings.ui.collectAsState()
    return !ui.liteMode && !com.opentune.ui.components.GlassPerformance.lite
}

/**
 * The cover itself behind the player, blurred smooth, the way the album and
 * playlist pages' headers show it: all of its colours blend into each other
 * rather than a few picked out as patches. It sits on the song's own tone, so
 * a dark cover still carries some colour, drifts and zooms slowly while
 * [moving], and darkens toward the bottom for the title and controls.
 * The cover is drawn tiny and stretched, which blends its colours on its
 * own, then blurred; before Android 12, which has no blur, the stretch alone does it.
 */
@Composable
private fun CoverBlur(artworkUrl: String?, moving: Boolean, modifier: Modifier = Modifier, tones: CoverTones? = null) {
    val scheme = MaterialTheme.colorScheme
    // Every frame where the phone keeps up, stepped like the mesh where it doesn't.
    val smooth = smoothBackdrop()
    val t by produceState(0f, moving, smooth) {
        if (!moving) return@produceState
        val start = withFrameNanos { it } - (value * 1e9f).toLong()
        while (true) {
            if (!smooth) delay(MESH_STEP_MS)
            value = (withFrameNanos { it } - start) / 1e9f
        }
    }
    val canBlur = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S
    Box(modifier.background(tones?.deep ?: lerp(scheme.surface, scheme.primaryContainer, 0.7f)).clipToBounds()) {
        androidx.compose.animation.Crossfade(artworkUrl, animationSpec = tween(900), label = "coverBlur") { url ->
            val context = androidx.compose.ui.platform.LocalContext.current
            // Drawn below into a small bitmap through a software canvas, which can't read a
            // hardware bitmap (Coil's default), so this one is decoded as an ordinary one.
            val painter = coil3.compose.rememberAsyncImagePainter(
                remember(url) { coil3.request.ImageRequest.Builder(context).data(url.artworkAt(120)).size(96).allowHardware(false).build() },
            )
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer {
                        val s = 1.45f + 0.07f * sin(t * 0.21f)
                        scaleX = s; scaleY = s
                        translationX = size.width * 0.05f * sin(t * 0.13f)
                        translationY = size.height * 0.04f * cos(t * 0.11f)
                        // A little of the song's tone under it shows through, so a dark cover isn't black.
                        alpha = 0.82f
                    }
                    .then(if (canBlur) Modifier.blur(60.dp, androidx.compose.ui.draw.BlurredEdgeTreatment.Unbounded) else Modifier)
                    .drawWithCache {
                        // The cover drawn into a tiny image, then stretched over the screen with
                        // smooth filtering: the stretch itself blends its colours into soft fields,
                        // whatever the image loader decoded, and the blur smooths what's left.
                        val small = androidx.compose.ui.graphics.ImageBitmap(COVER_BLUR_PX, COVER_BLUR_PX)
                        val loaded = painter.state.value is coil3.compose.AsyncImagePainter.State.Success
                        if (loaded) {
                            androidx.compose.ui.graphics.drawscope.CanvasDrawScope().draw(
                                this, layoutDirection, androidx.compose.ui.graphics.Canvas(small),
                                androidx.compose.ui.geometry.Size(COVER_BLUR_PX.toFloat(), COVER_BLUR_PX.toFloat()),
                            ) { with(painter) { draw(size) } }
                            // Softened in place too, so even a cover split hard in two comes out as one
                            // gradual fade, whether or not the blur effect below is there to help.
                            small.asAndroidBitmap().let { b ->
                                val px = IntArray(COVER_BLUR_PX * COVER_BLUR_PX)
                                b.getPixels(px, 0, COVER_BLUR_PX, 0, 0, COVER_BLUR_PX, COVER_BLUR_PX)
                                softenSquare(px, COVER_BLUR_PX, radius = 5, passes = 3)
                                b.setPixels(px, 0, COVER_BLUR_PX, 0, 0, COVER_BLUR_PX, COVER_BLUR_PX)
                            }
                        }
                        val side = maxOf(size.width, size.height)
                        onDrawBehind {
                            if (!loaded) return@onDrawBehind
                            drawImage(
                                small,
                                dstOffset = androidx.compose.ui.unit.IntOffset(((size.width - side) / 2).toInt(), ((size.height - side) / 2).toInt()),
                                dstSize = androidx.compose.ui.unit.IntSize(side.toInt(), side.toInt()),
                                filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
                            )
                        }
                    },
            )
        }
        // Darker toward the bottom so the title and controls stay readable: into the cover's own
        // near-black rather than grey, so the colours deepen instead of going muddy.
        val shade = tones?.base ?: Color.Black
        Box(
            Modifier.matchParentSize().background(
                Brush.verticalGradient(0f to shade.copy(alpha = 0.1f), 0.5f to shade.copy(alpha = 0.34f), 1f to shade.copy(alpha = 0.66f)),
            ),
        )
    }
}

/**
 * A box blur run [passes] times over a [side] by [side] image of ARGB [px],
 * along rows then columns, edges held: three passes come close to a
 * Gaussian. For Cover blur's tiny image, where it costs next to nothing.
 */
internal fun softenSquare(px: IntArray, side: Int, radius: Int, passes: Int) {
    val tmp = IntArray(px.size)
    fun pass(src: IntArray, dst: IntArray, step: Int, line: Int) {
        for (l in 0 until side) for (i in 0 until side) {
            var a = 0; var r = 0; var g = 0; var b = 0
            for (k in -radius..radius) {
                val j = (i + k).coerceIn(0, side - 1)
                val c = src[l * line + j * step]
                a += c ushr 24; r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF
            }
            val n = radius * 2 + 1
            dst[l * line + i * step] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
    }
    repeat(passes) {
        pass(px, tmp, step = 1, line = side) // along each row
        pass(tmp, px, step = side, line = 1) // down each column
    }
}

/** The size, in pixels, the cover is drawn at before Cover blur stretches it over the screen. */
private const val COVER_BLUR_PX = 32

private const val MESH_BLOBS = 5
private const val MESH_CYCLE_NS = 40_000_000_000L
private const val MESH_STEP_MS = 80L

/** Each patch's resting place (x, y as fractions), its turns per drift across and down, and where it starts. */
private val MESH_PATHS = arrayOf(
    floatArrayOf(0.15f, 0.1f, 1f, 1f, 0f),
    floatArrayOf(0.9f, 0.36f, -1f, 2f, 1.7f),
    floatArrayOf(0.1f, 0.62f, 2f, -1f, 3.4f),
    floatArrayOf(0.78f, 0.74f, 1f, -2f, 4.6f),
    floatArrayOf(0.4f, 0.98f, -2f, 1f, 2.2f),
)

/**
 * Large cover art. It eases smaller while paused, crossfades on a track
 * change, and can be swiped sideways to skip.
 */
@Composable
fun ArtworkPane(
    song: Song,
    isPlaying: Boolean,
    onSwipeNext: () -> Unit,
    onSwipePrevious: () -> Unit,
    modifier: Modifier = Modifier,
    moving: Boolean = false,
    artworkMotion: com.opentune.ui.components.ArtworkMotion? = null,
    change: com.opentune.data.settings.CoverChange = com.opentune.data.settings.CoverChange.FADE,
    /** The song's place in the queue, so Carousel knows which way to slide. */
    index: Int = 0,
    /** Double-tapping the cover's left or right side jumps by this many milliseconds back or on. */
    onSeekBy: ((Long) -> Unit)? = null,
    /** A soft light in the cover's colour under it, swelling with the bass. */
    glow: Boolean = false,
    /** Apple's animated cover for this song, looped over the still one. */
    video: com.opentune.data.covers.AppleMotionArt.Motion? = null,
    /**
     * Spotify's Canvas is playing behind the player: the still cover over it fades away,
     * keeping its place, so the clip shows and swipes and taps on it still work.
     */
    canvasShowing: Boolean = false,
    /** How round the cover's corners are. */
    corner: androidx.compose.ui.unit.Dp = 28.dp,
) {
    val coverShown by animateFloatAsState(if (canvasShowing) 0f else 1f, tween(450), label = "coverOverCanvas")
    val scale by animateFloatAsState(
        if (isPlaying) 1f else 0.86f,
        spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow),
        label = "artScale",
    )
    // The opening cover morph lands on this cover; tell it where and how big.
    com.opentune.ui.components.PlayerMorph.playerCoverScale = scale
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { com.opentune.ui.components.PlayerMorph.playerCover = null } }
    val offsetX = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val threshold = with(LocalDensity.current) { 96.dp.toPx() }

    Box(
        modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        val dx = offsetX.value
                        when {
                            dx < -threshold -> onSwipeNext()
                            dx > threshold -> onSwipePrevious()
                        }
                        scope.launch { offsetX.animateTo(0f, spring(dampingRatio = 0.7f)) }
                    },
                    onDragCancel = { scope.launch { offsetX.animateTo(0f) } },
                ) { change, amount ->
                    change.consume()
                    scope.launch { offsetX.snapTo(offsetX.value + amount) }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        if (glow && !canvasShowing) CoverGlow(isPlaying, scale, Modifier.matchParentSize())
        Box(Modifier.graphicsLayer { alpha = coverShown }, contentAlignment = Alignment.Center) {
            CoverSwap(CoverShown(song.thumbnailUrl, index, song.videoId), change) { url, motion ->
                UpgradingArtwork(
                    url.artworkAt(com.opentune.data.model.PLAYER_ART_PX),
                    // As wide as the pane, unless that's taller than the room it has: then as
                    // tall as the room. Forcing the full width made a square that spilled over
                    // "Playing from" and the title on screens where the controls take more height.
                    Modifier
                        .aspectRatio(1f)
                        .then(motion)
                        .then(with(com.opentune.ui.components.PlayerMorph) { Modifier.playerLanding() })
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offsetX.value
                            rotationZ = offsetX.value / 90f
                            // A soft, light shadow: Android casts an elevation shadow from a light
                            // above the screen, and at full strength under a cover this size its lower
                            // edge showed as a dark curve below the bottom corners.
                            shadowElevation = 16.dp.toPx()
                            ambientShadowColor = Color.Black.copy(alpha = 0.22f)
                            spotShadowColor = Color.Black.copy(alpha = 0.16f)
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(corner)
                            clip = true
                            // Hidden under the morphing cover while it grows in or shrinks away.
                            alpha = if (com.opentune.ui.components.PlayerMorph.coverAway) 0f else 1f
                        },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(corner),
                    imageModifier = Modifier.livingArt(isPlaying, moving, artworkMotion),
                ) {
                    // Only on the playing song's cover, not on one leaving as the song changes.
                    if (video != null && !canvasShowing && url == song.thumbnailUrl) {
                        val quality = com.opentune.data.settings.AppSettings.ui.collectAsState().value.motionQuality
                        // Keyed on the quality, so a new choice in Settings takes effect at once.
                        androidx.compose.runtime.key(quality) {
                            LoopingVideo(video.url, isPlaying, Modifier.matchParentSize(), fallbackUrl = video.fallbackUrl, maxPx = quality.maxPx, maxBitrate = quality.maxBitrate)
                        }
                    }
                }
            }
        }
        if (onSeekBy != null) SeekTaps(onSeekBy, scale, Modifier.matchParentSize())
    }
}

/**
 * Double-tap the cover's left side to go back ten seconds, its right side
 * to go on: a ripple spreads from the finger over that half and a label
 * says how far, adding up while the taps keep coming.
 */
@Composable
internal fun SeekTaps(
    onSeekBy: (Long) -> Unit,
    scale: Float,
    modifier: Modifier,
    /**
     * What the taps go round. Wrapped, not covered: a layer laid over a cover took its
     * touches, so the swipes under it (next song, up to lyrics and the queue) never saw them.
     */
    content: @Composable androidx.compose.foundation.layout.BoxScope.() -> Unit = {},
) {
    val haptics = com.opentune.ui.components.rememberHaptics()
    val ripple = remember { Animatable(1f) }
    var side by remember { mutableStateOf(0) }
    var at by remember { mutableStateOf(Offset.Zero) }
    var total by remember { mutableStateOf(0) }
    var lastTap by remember { mutableStateOf(0L) }
    val scope = rememberCoroutineScope()
    Box(
        modifier.pointerInput(Unit) {
            detectTapGestures(onDoubleTap = { o ->
                val s = if (o.x < size.width / 2f) -1 else 1
                val now = android.os.SystemClock.uptimeMillis()
                total = if (s == side && now - lastTap < 1_200) total + 10 else 10
                side = s
                at = o
                lastTap = now
                haptics.tick()
                onSeekBy(s * 10_000L)
                scope.launch {
                    ripple.snapTo(0f)
                    ripple.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
                }
            })
        },
        contentAlignment = Alignment.Center,
    ) {
        content()
        val p = ripple.value
        if (p < 1f && side != 0) {
            val shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp)
            Canvas(Modifier.matchParentSize().graphicsLayer { scaleX = scale; scaleY = scale; clip = true; this.shape = shape }) {
                // Only the half that was tapped.
                val left = if (side < 0) 0f else size.width / 2f
                clipRect(left = left, right = left + size.width / 2f) {
                    drawRect(Color.Black.copy(alpha = 0.18f * (1f - p)))
                    drawCircle(Color.White.copy(alpha = 0.28f * (1f - p)), size.width * 0.75f * p, at)
                }
            }
            val label = if (side < 0) "« $total s" else "$total s »"
            Text(
                label,
                color = Color.White.copy(alpha = (1f - p * p).coerceIn(0f, 1f)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(if (side < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 36.dp)
                    .graphicsLayer { translationX = side * 10.dp.toPx() * p },
            )
        }
    }
}

/** A blurred light in the cover's colours under it, drifting a little lower and swelling with the bass. */
@Composable
private fun CoverGlow(playing: Boolean, scale: Float, modifier: Modifier) {
    val (a, b) = com.opentune.ui.theme.songAccents()
    val swell = remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        com.opentune.playback.AudioLevels.hold()
        onDispose { com.opentune.playback.AudioLevels.release() }
    }
    LaunchedEffect(playing) {
        var peak = 0.05f
        var last = 0L
        while (playing) {
            androidx.compose.runtime.withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceIn(0f, 0.1f)
                last = now
                val level = com.opentune.playback.AudioLevels.at(System.nanoTime())?.let { it.bass * 0.8f + it.level * 0.2f } ?: 0f
                peak = maxOf(level, peak * (1f - dt * 0.3f)).coerceAtLeast(0.02f)
                val target = (level / peak).coerceIn(0f, 1f)
                swell.floatValue += (target - swell.floatValue) * (dt * if (target > swell.floatValue) 6f else 2f).coerceAtMost(1f)
            }
        }
        swell.floatValue = 0f
    }
    val strength by animateFloatAsState(if (playing) 1f else 0.45f, tween(600), label = "glow")
    Canvas(modifier) {
        val s = swell.floatValue
        val w = size.width * scale
        val c = Offset(center.x, center.y + w * 0.12f)
        val r = w * (0.7f + 0.07f * s)
        val peak = (0.7f + 0.25f * s).coerceAtMost(1f) * strength
        // A straight fade to transparent black showed its edge as a line across the player.
        val stops = com.opentune.ui.components.glowStops(a, peak, b)
        drawCircle(Brush.radialGradient(*stops, center = c, radius = r), r, c)
    }
}

/**
 * A slim seek bar that thickens while dragged. Position is read in the draw
 * phase, so the bar moves every frame without recomposing anything.
 */
@Composable
fun SeekBar(
    position: () -> Long,
    buffered: () -> Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
    wavy: Boolean = false,
    playing: Boolean = false,
    /** The lyric line sung at a moment, shown above the finger while the bar is dragged. */
    lyricAt: ((Long) -> String?)? = null,
    /** Where the song's parts (verse, chorus) begin, in ms, marked as small gaps in the track. */
    marks: List<Long> = emptyList(),
    quality: (@Composable () -> Unit)? = null,
) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    // Where the finger let go (or tapped), held until the player has got there: the seek takes
    // a few frames, and drawn from the player's position at once the line went back to where
    // it was and then jumped to the new place.
    var heldFraction by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(heldFraction, durationMs) {
        val held = heldFraction ?: return@LaunchedEffect
        if (durationMs <= 0) { heldFraction = null; return@LaunchedEffect }
        val target = (held * durationMs).toLong()
        kotlinx.coroutines.withTimeoutOrNull(SEEK_HOLD_MS) {
            while (kotlin.math.abs(position() - target) > SEEK_LANDED_MS) androidx.compose.runtime.withFrameNanos { }
        }
        heldFraction = null
    }
    fun seekTo(f: Float) {
        if (durationMs <= 0) return
        heldFraction = f.coerceIn(0f, 1f)
        onSeek((f.coerceIn(0f, 1f) * durationMs).toLong())
    }
    var scrubStartY by remember { mutableStateOf(0f) }
    var fineScrubbing by remember { mutableStateOf(false) }
    // The wave travels while music plays and flattens out when it stops.
    // Only animated while it can be seen, so an idle bar costs no frames.
    val phaseState = if (wavy && playing) rememberWavePhase() else null
    val amplitude by animateFloatAsState(if (wavy && playing && dragFraction == null) 1f else 0f, tween(400), label = "amp")
    val look = AppSettings.ui.collectAsState().value
    val base = look.seekbarThickness.dp.dp
    val trackHeight by animateDpAsState(if (dragFraction != null) base * 2 else base, label = "track")
    // The dot rides the track; the line stands across it; "While dragging" only shows while held.
    val thumbShown = when (look.seekbarThumb) {
        com.opentune.data.settings.SeekbarThumb.DOT, com.opentune.data.settings.SeekbarThumb.LINE -> dragFraction == null
        com.opentune.data.settings.SeekbarThumb.TOUCH -> dragFraction != null
        com.opentune.data.settings.SeekbarThumb.NONE -> false
    }
    val thumbRadius by animateDpAsState(if (thumbShown) maxOf(7.dp, base * 0.9f + 3.dp) else 0.dp, label = "thumb")
    val lineThumb = look.seekbarThumb == com.opentune.data.settings.SeekbarThumb.LINE
    val active = when (look.seekbarColor) {
        com.opentune.data.settings.SeekbarColor.PLAIN -> MaterialTheme.colorScheme.onSurface
        else -> MaterialTheme.colorScheme.primary
    }
    val gradientEnd = MaterialTheme.colorScheme.tertiary
    val gradient = look.seekbarColor == com.opentune.data.settings.SeekbarColor.GRADIENT
    val shownMarks = if (look.seekbarMarks) marks else emptyList()
    val inactive = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
    val bufferedColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
    val markDot = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)

    val seekHaptics = com.opentune.ui.components.rememberHaptics()
    fun fraction(): Float = dragFraction ?: heldFraction
        ?: if (durationMs > 0) (position().toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    // Until the song's length is known there's nothing to seek: a band of light runs along the
    // track instead, so it reads as loading rather than stuck at the start.
    val loading = durationMs <= 0
    val sweep = if (loading) rememberInfiniteTransition(label = "seekLoading")
        .animateFloat(-0.3f, 1.3f, infiniteRepeatable(tween(1_300, easing = LinearEasing)), label = "sweep") else null
    val sheen = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)

    // A remote or keyboard focuses the bar and moves through the song with left and right.
    var focused by remember { mutableStateOf(false) }
    val focusRing = MaterialTheme.colorScheme.primary

    Column(modifier) {
        Box {
            if (lyricAt != null) ScrubLyric(dragFraction, durationMs, lyricAt)
            Canvas(
                Modifier
                    .fillMaxWidth()
                    // Reserve the actual touch target in layout; thick tracks and
                    // their handles must not spill into the quality button below.
                    .height(maxOf(48.dp, base * 6f))
                    .onFocusChanged { focused = it.isFocused }
                    .onKeyEvent { e ->
                        val step = seekStepMs(e.key, durationMs) ?: return@onKeyEvent false
                        if (e.type == KeyEventType.KeyDown) onSeek((position() + step).coerceIn(0L, durationMs))
                        true
                    }
                    .focusable()
                    // Redrawn every frame while playing; its own layer keeps that from
                    // re-recording the rest of the player.
                    .graphicsLayer()
                    .semantics {
                        contentDescription = "Playback position. Drag away from the bar for fine scrubbing."
                        progressBarRangeInfo = ProgressBarRangeInfo(fraction(), 0f..1f)
                        setProgress { value ->
                            if (durationMs <= 0) false else {
                                onSeek((value.coerceIn(0f, 1f) * durationMs).toLong()); true
                            }
                        }
                    }
                    .pointerInput(durationMs) {
                        detectTapGestures { offset ->
                            seekTo(offset.x / size.width)
                        }
                    }
                    .pointerInput(durationMs) {
                        detectHorizontalDragGestures(
                            onDragStart = { scrubStartY = it.y; dragFraction = (it.x / size.width).coerceIn(0f, 1f) },
                            onDragEnd = {
                                dragFraction?.let { seekTo(it) }
                                dragFraction = null
                                fineScrubbing = false
                            },
                            onDragCancel = { dragFraction = null; fineScrubbing = false },
                        ) { change, delta ->
                            change.consume()
                            fineScrubbing = kotlin.math.abs(change.position.y - scrubStartY) > 48.dp.toPx()
                            val speed = if (fineScrubbing) 0.2f else 1f
                            val f = ((dragFraction ?: 0f) + delta / size.width * speed).coerceIn(0f, 1f)
                            // A soft tick each time the drag crosses a tenth of the song, and a firmer one at either end.
                            val before = dragFraction
                            if (before != null && (before * 10).toInt() != (f * 10).toInt()) seekHaptics.tick()
                            if (before != null && before > 0f && before < 1f && (f == 0f || f == 1f)) seekHaptics.press()
                            dragFraction = f
                        }
                    },
            ) {
                val h = trackHeight.toPx() * (if (focused) 2f else 1f)
                val y = (size.height - h) / 2
                val r = CornerRadius(h / 2)
                val f = fraction()
                if (focused) drawRoundRect(focusRing, Offset(-3.dp.toPx(), y - 3.dp.toPx()), Size(size.width + 6.dp.toPx(), h + 6.dp.toPx()), CornerRadius(h / 2 + 3.dp.toPx()), style = Stroke(2.dp.toPx()))
                val b = if (durationMs > 0) (buffered().toFloat() / durationMs).coerceIn(0f, 1f) else 0f
                // Under the wave, the straight track starts where the played part ends: drawn the
                // whole way along, it showed as a flat line behind the wave.
                val trackFrom = if (amplitude > 0f && sweep == null) (size.width * f + h * 1.5f * amplitude).coerceAtMost(size.width) else 0f
                if (trackFrom < size.width) drawRoundRect(inactive, Offset(trackFrom, y), Size(size.width - trackFrom, h), r)
                if (sweep != null) {
                    val at = sweep.value * size.width
                    val band = size.width * 0.25f
                    drawRoundRect(
                        Brush.horizontalGradient(0f to sheen.copy(alpha = 0f), 0.5f to sheen, 1f to sheen.copy(alpha = 0f), startX = at - band, endX = at + band),
                        Offset(0f, y), Size(size.width, h), r,
                    )
                    return@Canvas
                }
                val bufferedTo = size.width * maxOf(b, f)
                if (bufferedTo > trackFrom) drawRoundRect(bufferedColor, Offset(trackFrom, y), Size(bufferedTo - trackFrom, h), r)
                if (amplitude > 0f) {
                    // Played part as a sine wave, a stroke as thick as the track.
                    val amp = h * 0.9f * amplitude
                    val length = h * 7f
                    val wavePath = Path().apply {
                        moveTo(0f, size.height / 2)
                        var x = 0f
                        while (x <= size.width * f) {
                            lineTo(x, size.height / 2 + amp * sin(x / length * 2 * PI.toFloat() + (phaseState?.value ?: 0f)))
                            x += 2f
                        }
                    }
                    if (gradient) drawPath(wavePath, Brush.horizontalGradient(listOf(active, gradientEnd), endX = maxOf(size.width * f, 1f)), style = Stroke(width = h, cap = StrokeCap.Round))
                    else drawPath(wavePath, active, style = Stroke(width = h, cap = StrokeCap.Round))
                } else if (lineThumb && thumbRadius > 0.dp) {
                    // Clip the full capsule at the handle instead of rounding the
                    // played segment there. Its outer edge stays round; the join
                    // stays flush even with a thick track and a narrow line thumb.
                    clipRect(right = size.width * f) {
                        if (gradient) drawRoundRect(Brush.horizontalGradient(listOf(active, gradientEnd), endX = maxOf(size.width * f, 1f)), Offset(0f, y), Size(size.width, h), r)
                        else drawRoundRect(active, Offset(0f, y), Size(size.width, h), r)
                    }
                } else if (gradient) {
                    drawRoundRect(Brush.horizontalGradient(listOf(active, gradientEnd), endX = maxOf(size.width * f, 1f)), Offset(0f, y), Size(size.width * f, h), r)
                } else {
                    drawRoundRect(active, Offset(0f, y), Size(size.width * f, h), r)
                }
                // A small dot where each part of the song still to come begins. Ones already
                // played aren't drawn: cut into the played line (the wave above all) they read as breaks.
                if (durationMs > 0) {
                    val played = size.width * f
                    val clear = maxOf(thumbRadius.toPx(), h) + 2.dp.toPx()
                    shownMarks.forEach { ms ->
                        val x = size.width * (ms.toFloat() / durationMs)
                        if (x > played + clear && x < size.width - h) drawCircle(markDot, h * 0.32f, Offset(x, size.height / 2))
                    }
                }
                if (thumbRadius > 0.dp) {
                    val at = Offset(size.width * f, size.height / 2)
                    val thumbColor = if (gradient) gradientEnd else active
                    if (lineThumb) {
                        // A short upright bar across the track, rounded at the ends.
                        val w = 3.dp.toPx()
                        val tall = thumbRadius.toPx() * 2.6f
                        drawRoundRect(thumbColor, Offset(at.x - w / 2f, at.y - tall / 2f), Size(w, tall), CornerRadius(w / 2f))
                    } else {
                        drawCircle(thumbColor, thumbRadius.toPx(), at)
                    }
                }
            }
        }
        if (fineScrubbing) Text("Fine scrubbing · ⅕ speed", style = MaterialTheme.typography.labelSmall)
        val elapsedSeconds by remember(durationMs) {
            derivedStateOf { (((dragFraction ?: heldFraction)?.times(durationMs)?.toLong() ?: position()) / 1000) }
        }
        if (look.seekbarTime != com.opentune.data.settings.SeekbarTime.HIDDEN) {
            val timeStyle = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum")
            val measurer = androidx.compose.ui.text.rememberTextMeasurer()
            val density = LocalDensity.current
            // Reserve identical, stable side columns using the whole track's length.
            // Seconds changing width must never push the quality label sideways.
            val timeWidth = remember(durationMs, timeStyle, density) {
                val sample = if (durationMs > 0) "-" + formatTime(durationMs) else "--:--"
                with(density) { (measurer.measure(sample, timeStyle).size.width + 8.dp.roundToPx()).toDp() }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (loading) "--:--" else formatTime(elapsedSeconds * 1000), modifier = Modifier.width(timeWidth),
                    style = timeStyle, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                // Keep this button below the seek target, including its minimum touch bounds.
                quality?.let { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { it() } }
                Text(
                    when {
                        durationMs <= 0 -> "--:--"
                        look.seekbarTime == com.opentune.data.settings.SeekbarTime.TOTAL -> formatTime(durationMs)
                        else -> "-" + formatTime((durationMs - elapsedSeconds * 1000).coerceAtLeast(0))
                    },
                    modifier = Modifier.width(timeWidth),
                    style = timeStyle,
                    textAlign = androidx.compose.ui.text.style.TextAlign.End,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
        if (look.seekbarTime == com.opentune.data.settings.SeekbarTime.HIDDEN) quality?.let { Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) { it() } }
    }
}

/** The wave's travel, 0 to 2π, looping. */
@Composable
private fun rememberWavePhase(): androidx.compose.runtime.State<Float> =
    rememberInfiniteTransition(label = "wave")
        .animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1_600, easing = LinearEasing)), label = "phase")

/**
 * Now playing, above the dock: a card tinted with the cover's colour, with
 * the song's progress as a ring around the play button. Swipe it sideways to
 * skip. [inline] is the round bubble the card becomes while a page scrolls:
 * the cover in a circle, ringed by progress; tap it to open the player.
 */
/** Commands for the mini player's one swipe-down writer (see MiniPlayer). */
private sealed interface MiniDragCommand {
    data class Move(val y: Float) : MiniDragCommand
    data object SpringBack : MiniDragCommand
    data object Dismiss : MiniDragCommand
}

@Composable
fun MiniPlayer(
    song: Song,
    isPlaying: Boolean,
    isBuffering: Boolean,
    hasNext: Boolean,
    progress: () -> Float,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onClick: () -> Unit,
    onDismiss: () -> Unit = {},
    modifier: Modifier = Modifier,
    inline: Boolean = false,
    /**
     * A still copy drawn inside the shrinking player card (see PlayerSheet):
     * the same look, with no gestures, a solid face instead of glass, and
     * not registered as where the mini player is.
     */
    replica: Boolean = false,
) {
    val offsetX = remember { Animatable(0f) }
    val offsetY = remember { Animatable(0f) }
    // Swipe-down positions and releases arrive here as commands, and this
    // one writer executes them in order. Moves are chased with a stiff,
    // critically damped spring — drawn per frame, so the card glides
    // between the coarse steps of the incoming events instead of jumping
    // event to event (the trembling). One writer also means a release can
    // never fight an in-flight move: the command simply replaces it.
    val dragPositions = remember { kotlinx.coroutines.channels.Channel<MiniDragCommand>(kotlinx.coroutines.channels.Channel.CONFLATED) }
    LaunchedEffect(Unit) {
        // collectLatest by hand: each new command cancels the in-flight
        // animation and takes its place. (receiveAsFlow is not available
        // in this project's coroutines setup, so no Flow bridge.)
        var job: kotlinx.coroutines.Job? = null
        for (cmd in dragPositions) {
            job?.cancel()
            job = launch {
                when (cmd) {
                    is MiniDragCommand.Move -> offsetY.snapTo(cmd.y)
                    MiniDragCommand.SpringBack -> offsetY.animateTo(0f, spring(dampingRatio = 0.7f))
                    MiniDragCommand.Dismiss -> {
                        offsetY.animateTo(480f, tween(160))
                        onDismiss()
                    }
                }
            }
        }
    }
    // The chrome mirrors this so it can keep the card behind the dock while
    // it is pulled down; the sheet's replica never drags, and never writes.
    if (!replica) {
        LaunchedEffect(Unit) {
            snapshotFlow { offsetY.value }.collect { com.opentune.ui.components.PlayerMorph.miniDismiss = it }
        }
    }
    val scope = rememberCoroutineScope()
    val threshold = with(LocalDensity.current) { 72.dp.toPx() }
    val dismissThreshold = with(LocalDensity.current) { 56.dp.toPx() }
    val accent = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f)
    // The cover's own colour, faded into the glass, so each song tints the card.
    val seed = rememberArtworkSeed(song.thumbnailUrl)
    val colourFromCover = com.opentune.data.settings.AppSettings.ui.collectAsState().value.miniPlayerTint
    val tint by animateColorAsState(((if (colourFromCover) seed else null) ?: MaterialTheme.colorScheme.surfaceContainerHigh).copy(alpha = 0.38f), tween(600), label = "miniTint")

    val solid = MaterialTheme.colorScheme.surfaceContainerHigh
    val replicaFace = androidx.compose.ui.graphics.lerp(solid, tint.copy(alpha = 1f), tint.alpha)
    val landing: Modifier = if (replica) Modifier else with(com.opentune.ui.components.PlayerMorph) { Modifier.miniLanding().hiddenWhilePulled() }
    if (inline) {
        Box(
            modifier
                .then(
                    if (replica) Modifier.background(replicaFace)
                    else with(com.opentune.ui.components.PlayerMorph) { Modifier.miniBarLanding(round = true).miniUnderCard() }
                        .glass(CircleShape, tint, swell = false)
                        .pullToOpen(round = true, onOpen = onClick)
                        .clickable(onClick = onClick),
                )
                .padding(4.dp),
            contentAlignment = Alignment.Center,
        ) {
            ProgressRing(progress, accent, track, stroke = 3.dp, modifier = Modifier.matchParentSize())
            Artwork(song.thumbnailUrl.artworkAt(ROW_ART_PX), Modifier.padding(4.dp).fillMaxSize().then(landing), CircleShape)
            if (isBuffering) CircularProgressIndicator(Modifier.matchParentSize(), strokeWidth = 3.dp, color = accent)
        }
        return
    }

    val shape = RoundedCornerShape(22.dp)
    if (replica) {
        Box(modifier.background(replicaFace)) { MiniRow(song, isPlaying, isBuffering, hasNext, progress, accent, track, {}, {}, landing) }
        return
    }
    Surface(
        onClick = onClick,
        shape = shape,
        color = Color.Transparent,
        modifier = modifier
            .then(with(com.opentune.ui.components.PlayerMorph) { Modifier.miniBarLanding(round = false).miniUnderCard() })
            .graphicsLayer {
                translationX = offsetX.value
                translationY = offsetY.value
                alpha = 1f - (offsetY.value / (dismissThreshold * 2.2f)).coerceIn(0f, 0.8f)
            }
            .glass(shape, tint, swell = false)
            .pullToOpen(round = false, onOpen = onClick)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        when {
                            offsetX.value < -threshold -> onNext()
                            offsetX.value > threshold -> onPrevious()
                        }
                        scope.launch { offsetX.animateTo(0f, spring(dampingRatio = 0.7f)) }
                    },
                    onDragCancel = { scope.launch { offsetX.animateTo(0f) } },
                ) { change, amount ->
                    change.consume()
                    scope.launch { offsetX.snapTo(offsetX.value + amount * 0.6f) }
                }
            }
            .pointerInput(Unit) {
                // Swipe down to dismiss. Upward pulls belong to pullToOpen
                // (downward is a dead direction there: pulled clamps at 0)
                // and sideways swipes to the detector above, so this watcher
                // takes over only a clearly downward drag: the card follows
                // the finger down and fades, letting go past the line
                // dismisses playback, short of it the card springs back.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var decided = false
                    var engaged = false
                    var lastMoveY = 0f
                    var accX = 0f
                    var accY = 0f
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) {
                            if (engaged) {
                                change.consume()
                                if (lastMoveY > dismissThreshold) dragPositions.trySend(MiniDragCommand.Dismiss)
                                else dragPositions.trySend(MiniDragCommand.SpringBack)
                            }
                            break
                        }
                        // Accumulate the framework's own per-event deltas,
                        // exactly like the sideways detector. Subtracting
                        // consecutive positions by hand is NOT the same: the
                        // card moves with this very drag, so each event's
                        // position arrives expressed against a different
                        // card position and the difference measures the
                        // card's own motion too — the two fight (the
                        // trembling). positionChange() is kept consistent
                        // by the framework, so it only ever measures the
                        // finger.
                        val ddx = change.positionChange().x
                        val ddy = change.positionChange().y
                        accX += ddx
                        accY += ddy
                        if (!decided) {
                            when {
                                accY > viewConfiguration.touchSlop && accY > kotlin.math.abs(accX) * 1.2f -> {
                                    decided = true
                                    engaged = true
                                }
                                accY < -viewConfiguration.touchSlop || kotlin.math.abs(accX) > viewConfiguration.touchSlop -> decided = true
                            }
                        }
                        if (engaged) {
                            change.consume()
                            lastMoveY = (accY - viewConfiguration.touchSlop).coerceAtLeast(0f)
                            dragPositions.trySend(MiniDragCommand.Move(lastMoveY))
                        }
                    }
                }
            },
    ) {
        MiniRow(song, isPlaying, isBuffering, hasNext, progress, accent, track, onTogglePlay, onNext, landing)
    }
}

/** The mini player's row: cover, title and artist, play in its progress ring, next. */
@Composable
private fun MiniRow(
    song: Song, isPlaying: Boolean, isBuffering: Boolean, hasNext: Boolean, progress: () -> Float,
    accent: Color, track: Color, onTogglePlay: () -> Unit, onNext: () -> Unit, landing: Modifier,
) {
    Row(Modifier.fillMaxSize().padding(start = 10.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        AnimatedContent(song, transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) }, label = "mini", modifier = Modifier.weight(1f)) { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Artwork(s.thumbnailUrl.artworkAt(ROW_ART_PX), Modifier.size(44.dp).then(landing), RoundedCornerShape(12.dp))
                Column(Modifier.padding(start = 12.dp)) {
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    com.opentune.ui.components.SubtitleLine(s.artist, explicit = s.isExplicit == true, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        // Play inside the progress ring.
        Box(Modifier.size(46.dp).clip(CircleShape).clickable(onClick = onTogglePlay), contentAlignment = Alignment.Center) {
            ProgressRing(progress, accent, track, stroke = 2.5.dp, modifier = Modifier.matchParentSize().padding(3.dp))
            if (isBuffering) CircularProgressIndicator(Modifier.matchParentSize().padding(3.dp), strokeWidth = 2.5.dp, color = accent)
            Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pause" else "Play", Modifier.size(24.dp))
        }
        IconButton(onClick = onNext, enabled = hasNext) {
            Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(26.dp))
        }
    }
}

/**
 * Swiping the mini player up opens the player, the cover growing out of it
 * with the finger as it goes (see [com.opentune.ui.components.PlayerMorph.pullOpen]).
 * Far enough and it opens, the flight finishing from there; short of that it
 * settles back. With motion reduced it just opens past the line.
 */
@Composable
private fun Modifier.pullToOpen(round: Boolean, onOpen: () -> Unit): Modifier {
    val reduce = com.opentune.data.settings.AppSettings.ui.collectAsState().value.reduceAnimation
    val scope = rememberCoroutineScope()
    val back = remember { Animatable(0f) }
    val density = LocalDensity.current
    val screenH = with(density) { androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val openPx = with(density) { 90.dp.toPx() }
    val open by androidx.compose.runtime.rememberUpdatedState(onOpen)
    val morph = com.opentune.ui.components.PlayerMorph
    // Read and written on the gesture itself, never from a launched step: a
    // step landing after the finger lifts would pull the cover back up once
    // the player has started opening, and leave it hanging there.
    var pulled by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    fun settle(from: Float) = scope.launch {
        back.snapTo(from)
        back.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 500f)) { if (!reduce) morph.pullOpen(value, round, screenH) }
        morph.endPull()
    }
    // Taken away mid-pull (the player opened over it, the dock folded): let go of the cover.
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { morph.endPull() } }
    return pointerInput(round, reduce) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            pulled = 0f
            morph.pullFlingPx = 0f
            scope.launch { back.stop() }
            var lastT = down.uptimeMillis
            var velPx = 0f
            var engaged = false
            var released = false
            try {
                while (true) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                    if (!change.pressed) {
                        released = true
                        val far = pulled
                        pulled = 0f
                        if (engaged) change.consume()
                        if (far >= openPx || morph.pulling >= 0.25f) {
                            morph.pullFlingPx = velPx
                            open()
                        } else {
                            settle(far)
                        }
                        break
                    }
                    // The framework's own delta, never positions subtracted
                    // by hand: the bar itself moves with other drags (the
                    // dismiss below, the chrome scroll), and a hand-made
                    // difference would measure that motion too and read a
                    // downward drag as an upward pull.
                    val dy = change.positionChange().y
                    if (dy < 0f || pulled > 0f) {
                        pulled = (pulled - dy).coerceAtLeast(0f)
                        if (pulled > 0f) {
                            engaged = true
                            change.consume()
                            if (!reduce) morph.pullOpen(pulled, round, screenH)
                            val dt = (change.uptimeMillis - lastT).toFloat()
                            if (dt > 0f) velPx = velPx * 0.6f + (-dy / dt * 1000f) * 0.4f
                        }
                    }
                    lastT = change.uptimeMillis
                }
            } finally {
                if (!released && pulled > 0f) {
                    val far = pulled
                    pulled = 0f
                    settle(far)
                }
            }
        }
    }
}

/** The mini player's cover steps aside while the flying copy of it is pulled up. */
private fun Modifier.hiddenWhilePulled(): Modifier = graphicsLayer {
    // When the whole player is pulled up instead, the mini player keeps its cover under the card.
    alpha = if (com.opentune.ui.components.PlayerMorph.pulling > 0f && !com.opentune.ui.components.PlayerMorph.sheetMorph) 0f else 1f
}

/** A circle that fills clockwise from the top as [progress] goes 0 to 1. */
@Composable
private fun ProgressRing(progress: () -> Float, color: Color, track: Color, stroke: Dp, modifier: Modifier = Modifier) {
    // Its own layer: the ring redraws as the song plays, the glass under it needn't.
    Canvas(modifier.graphicsLayer()) {
        val w = stroke.toPx()
        val inset = w / 2
        val arcSize = Size(size.width - w, size.height - w)
        drawArc(track, 0f, 360f, useCenter = false, topLeft = Offset(inset, inset), size = arcSize, style = Stroke(w))
        drawArc(color, -90f, 360f * progress().coerceIn(0f, 1f), useCenter = false, topLeft = Offset(inset, inset), size = arcSize, style = Stroke(w, cap = StrokeCap.Round))
    }
}

/** One line naming where the song is playing from, as a plain label, or "Now playing" when there isn't one. */
@Composable
fun SongStatus(source: String?) {
    Text(
        if (source.isNullOrBlank()) "Now playing" else com.opentune.i18n.Tr.f("Playing from {0}", source),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
    )
}

/** Codec, bitrate, sample rate and channels of what's actually playing. */
@Composable
fun NerdStatsLine(format: AudioFormatInfo?) {
    val picked by NerdStats.lastPicked.collectAsState()
    val startup by NerdStats.startupMs.collectAsState()
    val gain by NerdStats.loudnessGainDb.collectAsState()
    val engine by NerdStats.engine.collectAsState()
    val lossless by NerdStats.externalSource.collectAsState()
    val kbps = format?.bitrateKbps ?: picked?.second.takeIf { lossless == null }
    val parts = listOfNotNull(
        format?.codec,
        format?.bitDepth?.takeIf { it > 0 }?.let { "$it-bit" },
        kbps?.let { com.opentune.i18n.Tr.f("{0} kbps", it) },
        format?.sampleRateHz?.let { "%.1f kHz".format(it / 1000f) },
        format?.channels?.let { if (it == 2) "stereo" else if (it == 1) "mono" else com.opentune.i18n.Tr.f("{0} ch", it) },
        gain?.let { com.opentune.i18n.Tr.t("normalized %+.1f dB").format(it) },
        startup?.let { com.opentune.i18n.Tr.f("started in {0} ms", it) },
        (lossless ?: engine)?.let { com.opentune.i18n.Tr.f("via {0}", it) },
    )
    Text(
        parts.joinToString(" · ").ifEmpty { "Waiting for stream…" },
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
    )
}

/** Volume of the active output: the cast receiver when connected, otherwise the phone. */
@Composable
fun VolumeBar(modifier: Modifier = Modifier) {
    val session by com.opentune.cast.Cast.session.collectAsState()
    val receiver = session?.receiver
    // Cancel gestures and pending UI work when the output changes.
    androidx.compose.runtime.key(receiver) { OutputVolumeBar(receiver, modifier) }
}

@Composable
internal fun OutputVolumeBar(receiver: com.opentune.cast.Receiver?, modifier: Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val am = remember { context.getSystemService(AudioManager::class.java) }
    val max = remember { am?.getStreamMaxVolume(AudioManager.STREAM_MUSIC)?.coerceAtLeast(1) ?: 1 }
    val remoteVolume = receiver?.status?.collectAsState()?.value?.volume
    var volume by remember { mutableFloatStateOf(
        if (receiver != null) remoteVolume ?: 0f else (am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0).toFloat() / max
    ) }
    var dragging by remember { mutableStateOf(false) }
    var pending by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val commands = remember { kotlinx.coroutines.sync.Mutex() }
    LaunchedEffect(remoteVolume, dragging, pending) {
        if (receiver != null && !dragging && pending == 0) remoteVolume?.let { volume = it.coerceIn(0f, 1f) }
    }
    LaunchedEffect(am) {
        if (receiver != null) return@LaunchedEffect
        while (true) {
            if (!dragging) volume = (am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0).toFloat() / max
            delay(400)
        }
    }
    fun commit() {
        val level = volume
        if (receiver == null) {
            am?.setStreamVolume(AudioManager.STREAM_MUSIC, (level * max).roundToInt(), 0)
        } else {
            pending++
            scope.launch {
                try {
                    commands.withLock { receiver.setVolume(level) }
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    com.opentune.data.Pills.info(com.opentune.i18n.Tr.f("Couldn't change the volume on {0}", receiver.name), context)
                } finally {
                    pending--
                }
            }
        }
    }
    fun adjust(step: Float) {
        volume = (volume + step).coerceIn(0f, 1f)
        commit()
    }
    var focused by remember { mutableStateOf(false) }
    val focusInk = MaterialTheme.colorScheme.primary
    val step = if (receiver != null) 0.05f else 1f / max
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.AutoMirrored.Rounded.VolumeDown, "Volume down", tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp).clickable { adjust(-step) })
        val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
        val fill = MaterialTheme.colorScheme.onSurface
        fun preview(x: Float, width: Int) {
            if (width <= 0) return
            volume = (x / width).coerceIn(0f, 1f)
            if (receiver == null) commit()
        }
        Canvas(
            Modifier
                .weight(1f)
                .padding(horizontal = 10.dp)
                .height(28.dp)
                .onFocusChanged { focused = it.isFocused }
                .onKeyEvent { e ->
                    when (e.key) {
                        Key.DirectionLeft, Key.DirectionRight -> {
                            if (e.type == KeyEventType.KeyDown) adjust(if (e.key == Key.DirectionRight) step else -step)
                            true
                        }
                        else -> false
                    }
                }
                .focusable()
                .semantics {
                    contentDescription = receiver?.let { com.opentune.i18n.Tr.f("{0} volume", it.name) } ?: com.opentune.i18n.Tr.t("Media volume")
                    progressBarRangeInfo = ProgressBarRangeInfo(volume, 0f..1f)
                    setProgress { volume = it.coerceIn(0f, 1f); commit(); true }
                }
                .pointerInput(max, receiver) { detectTapGestures { preview(it.x, size.width); commit() } }
                .pointerInput(max, receiver) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = { commit(); dragging = false },
                        onDragCancel = { dragging = false },
                    ) { change, _ ->
                        change.consume()
                        preview(change.position.x, size.width)
                    }
                },
        ) {
            val h = (if (focused) 8.dp else 4.dp).toPx()
            val y = (size.height - h) / 2
            val f = volume.coerceIn(0f, 1f)
            drawRoundRect(track, Offset(0f, y), Size(size.width, h), CornerRadius(h / 2))
            if (focused) drawRoundRect(focusInk, Offset(0f, y - 3.dp.toPx()), Size(size.width, h + 6.dp.toPx()), CornerRadius(h), style = Stroke(2.dp.toPx()))
            drawRoundRect(fill, Offset(0f, y), Size(size.width * f, h), CornerRadius(h / 2))
        }
        Icon(Icons.AutoMirrored.Rounded.VolumeUp, "Volume up", tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp).clickable { adjust(step) })
    }
}

/** An empty area that still skips tracks on a sideways swipe, for full-screen cover mode. */
@Composable
fun ArtworkSwipeArea(
    onSwipeNext: () -> Unit,
    onSwipePrevious: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.BoxScope.() -> Unit = {},
) {
    val threshold = with(LocalDensity.current) { 96.dp.toPx() }
    var dx by remember { mutableFloatStateOf(0f) }
    Box(
        modifier.pointerInput(Unit) {
            detectHorizontalDragGestures(
                onDragStart = { dx = 0f },
                onDragEnd = {
                    when {
                        dx < -threshold -> onSwipeNext()
                        dx > threshold -> onSwipePrevious()
                    }
                },
            ) { change, amount ->
                change.consume()
                dx += amount
            }
        },
        content = content,
    )
}

/**
 * The cover as a record: round, with grooves and a spindle hole, turning
 * gently once every 20 seconds while playing, resting where it stopped on pause.
 */
@Composable
fun VinylPane(
    song: Song,
    isPlaying: Boolean,
    onSwipeNext: () -> Unit,
    onSwipePrevious: () -> Unit,
    animate: Boolean,
    modifier: Modifier = Modifier,
) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isPlaying, animate) {
        if (!isPlaying || !animate) return@LaunchedEffect
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) angle = (angle + (now - last) / 1_000_000_000f * VINYL_DEGREES_PER_SECOND) % 360f
                last = now
            }
        }
    }
    val groove = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)
    ArtworkSwipeArea(onSwipeNext = onSwipeNext, onSwipePrevious = onSwipePrevious, modifier = modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth(0.92f)
                .aspectRatio(1f)
                .align(Alignment.Center)
                .graphicsLayer {
                    rotationZ = angle
                    shadowElevation = 30.dp.toPx()
                    shape = CircleShape
                    clip = true
                }
                .background(Color(0xFF111111)),
            contentAlignment = Alignment.Center,
        ) {
            Artwork(
                song.thumbnailUrl.artworkAt(com.opentune.data.model.PLAYER_ART_PX),
                Modifier.fillMaxSize(0.62f).clip(CircleShape),
                CircleShape,
            )
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2
                // Grooves between the label and the rim.
                var ring = r * 0.66f
                while (ring < r * 0.98f) {
                    drawCircle(groove, radius = ring, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
                    ring += r * 0.035f
                }
                drawCircle(Color(0xFF111111), radius = r * 0.045f)
                drawCircle(Color.White.copy(alpha = 0.25f), radius = r * 0.045f, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
            }
        }
    }
}

private const val VINYL_DEGREES_PER_SECOND = 360f / 20f

/**
 * While the seek bar is dragged, the line sung at that point in a bubble
 * above the finger. It follows the finger, stays inside the bar's width
 * and changes as the finger crosses into another line.
 */
@Composable
private fun BoxScope.ScrubLyric(dragFraction: Float?, durationMs: Long, lyricAt: (Long) -> String?) {
    var last by remember { mutableStateOf<String?>(null) }
    var lastFraction by remember { mutableStateOf(0f) }
    val line = dragFraction?.let { lyricAt((it * durationMs).toLong()) }
    if (dragFraction != null) {
        lastFraction = dragFraction
        if (line != null) last = line
    }
    val shown by animateFloatAsState(if (dragFraction != null && last != null) 1f else 0f, spring(dampingRatio = 0.8f, stiffness = 500f), label = "scrubLyric")
    if (shown <= 0.01f || last == null) return
    val text = last!!
    Box(
        Modifier
            .layout { measurable, constraints ->
                val maxW = (constraints.maxWidth * 0.8f).toInt()
                val p = measurable.measure(androidx.compose.ui.unit.Constraints(maxWidth = maxW))
                layout(constraints.maxWidth, 0) {
                    val center = (constraints.maxWidth * lastFraction).toInt()
                    val x = (center - p.width / 2).coerceIn(0, (constraints.maxWidth - p.width).coerceAtLeast(0))
                    p.place(x, -p.height - 6.dp.roundToPx())
                }
            }
            .graphicsLayer {
                alpha = shown
                val s = 0.85f + 0.15f * shown
                scaleX = s
                scaleY = s
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)
                translationY = (1f - shown) * 8.dp.toPx()
            }
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.92f))
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        androidx.compose.animation.AnimatedContent(
            text,
            transitionSpec = { (fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 3 }) togetherWith fadeOut(tween(120)) },
            label = "scrubLine",
        ) { t ->
            Text(t, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

/** How far left or right on a remote moves the song: 10 seconds, or a fiftieth of a long one. */
internal fun seekStepMs(key: Key, durationMs: Long): Long? {
    if (durationMs <= 0) return null
    val step = maxOf(10_000L, durationMs / 50)
    return when (key) {
        Key.DirectionRight, Key.MediaFastForward -> step
        Key.DirectionLeft, Key.MediaRewind -> -step
        else -> null
    }
}

/** How long a let-go seek is held on the bar at most, waiting for the player to get there. */
private const val SEEK_HOLD_MS = 2_000L
/** Close enough to the let-go point to count as there. */
private const val SEEK_LANDED_MS = 700L
